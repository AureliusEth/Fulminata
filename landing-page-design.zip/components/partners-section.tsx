import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function PartnersSection() {
  const partners = [
    { name: "Solana", color: "#9945FF" },
    { name: "Ethereum", color: "#627EEA" },
    { name: "Avalanche", color: "#E84142" },
    { name: "Polygon", color: "#8247E5" },
    { name: "Chainlink", color: "#375BD2" },
    { name: "Fireblocks", color: "#FF6B35" },
    { name: "Circle", color: "#3B82F6" },
    { name: "Anchorage", color: "#1E3A5F" },
    { name: "BitGo", color: "#00AEEF" },
    { name: "Coinbase", color: "#0052FF" },
  ]

  return (
    <section id="ecosystem" className="py-24 bg-card/30">
      <div className="mx-auto max-w-4xl px-6 text-center">
        {/* Header */}
        <span className="text-sm text-primary tracking-wide">Partners</span>
        <h2 className="font-serif text-4xl md:text-5xl text-foreground mt-4 mb-6 leading-tight">
          Best-in-class Service Providers,
          <br />
          United by a Shared Mission.
        </h2>

        {/* Partner Logos */}
        <div className="flex flex-wrap justify-center gap-4 my-12">
          {partners.map((partner, index) => (
            <div
              key={index}
              className="w-16 h-16 rounded-full bg-secondary flex items-center justify-center"
              title={partner.name}
            >
              <div className="w-8 h-8 rounded-full" style={{ backgroundColor: partner.color, opacity: 0.8 }} />
            </div>
          ))}
        </div>

        {/* Description */}
        <div className="max-w-2xl mx-auto">
          <p className="text-muted-foreground mb-4 leading-relaxed">
            The Fulminata Ecosystem represents a strategic alliance of premier partners committed to advancing our
            mission. This network includes top-tier providers across liquidity, custody, and essential onchain
            infrastructure.
          </p>
          <p className="text-muted-foreground leading-relaxed">
            Through these partnerships, we're able to provide a truly comprehensive platform to provide our clients with
            access to top-tier solutions that support their success.
          </p>
        </div>

        {/* CTA */}
        <div className="mt-10">
          <Button variant="outline" className="border-border text-foreground hover:bg-secondary bg-transparent">
            Explore Ecosystem
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </section>
  )
}
