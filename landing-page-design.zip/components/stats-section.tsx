export function StatsSection() {
  return null
}
